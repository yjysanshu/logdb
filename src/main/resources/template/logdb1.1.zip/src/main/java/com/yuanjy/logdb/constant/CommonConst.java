package com.yuanjy.logdb.constant;

public class CommonConst {
    public static final int SUCCESS = 1;    //成功
    public static final int ERROR = 0;      //失败
}
